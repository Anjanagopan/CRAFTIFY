package com.example.craftify;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class Custom_seller_view_exhibition_request extends BaseAdapter {
    String[] product_id,product_name,photo,exname,exdate,exfromtime,extotime,status;
    Context context;

    public Custom_seller_view_exhibition_request(Context applicationContext, String[]product_id,String[]product_name,String[]photo,String[]exname,String[]exdate,String[]exfromtime,String[]extotime,String[]status) {
        this.context = applicationContext;
        this.product_id = product_id;
        this.product_name = product_name;
        this.photo = photo;
        this.exname = exname;
        this.exdate = exdate;
        this.exfromtime = exfromtime;
        this.extotime = extotime;
        this.status = status;

    }

    @Override
    public int getCount() {
        return photo.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup viewGroup) {
        LayoutInflater inflator = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View gridView;
        if (convertView == null) {
            gridView = new View(context);
            gridView = inflator.inflate(R.layout.custom_seller_view_request_status, null);

        } else {
            gridView = (View) convertView;

        }

        TextView tvname = (TextView) gridView.findViewById(R.id.textView15);
        TextView tvqty = (TextView) gridView.findViewById(R.id.textView16);
        TextView tvdetails = (TextView) gridView.findViewById(R.id.textView18);
        TextView tvprice = (TextView) gridView.findViewById(R.id.textView19);

        ImageView iv = (ImageView) gridView.findViewById(R.id.imageView4);


        tvname.setText(product_name[i]);
        tvqty.setText("Name :"+exname[i]);
        tvprice.setText("Date :"+exdate[i]+" Status :"+status[i]);
        tvdetails.setText("Time from :"+exfromtime[i]+"-- To:"+extotime[i]);

        SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(context.getApplicationContext());
        String ip = sh.getString("ip", "");
        String url = "http://" + ip + ":5050" + photo[i];
        Picasso.with(context.getApplicationContext()).load(url).into(iv);


        return gridView;

    }
}