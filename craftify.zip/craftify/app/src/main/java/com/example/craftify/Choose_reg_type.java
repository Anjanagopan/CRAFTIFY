package com.example.craftify;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class Choose_reg_type extends AppCompatActivity implements View.OnClickListener {
ImageView imguser,imgseller;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_reg_type);
        imguser=(ImageView) findViewById(R.id.imguser);
        imgseller=(ImageView) findViewById(R.id.imgseller);
        imguser.setOnClickListener(this);
        imgseller.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view==imguser){
            startActivity(new Intent(getApplicationContext(),User_signup.class));
        }else if(view==imgseller){
            startActivity(new Intent(getApplicationContext(),signup.class));
        }
    }
}