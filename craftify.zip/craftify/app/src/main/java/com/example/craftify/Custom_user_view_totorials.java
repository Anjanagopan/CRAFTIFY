package com.example.craftify;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.VideoView;

import com.squareup.picasso.Picasso;

public class Custom_user_view_totorials extends BaseAdapter {

    String[] video_id,video_name,title,description,v_date,uname,uimg;
    Context context;

    public Custom_user_view_totorials(Context applicationContext, String[] video_id, String[]  video_name, String[]  title, String[]  description, String[]  v_date, String[]  uname, String[]  uimg) {
        this.context = applicationContext;
        this.video_id = video_id;
        this.video_name = video_name;
        this.title = title;
        this.description = description;
        this.v_date = v_date;
        this.uname = uname;
        this.uimg = uimg;
    }

    @Override
    public int getCount() {
        return v_date.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup viewGroup) {
        LayoutInflater inflator = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View gridView;
        if (convertView == null) {
            gridView = new View(context);
            gridView = inflator.inflate(R.layout.custom_user_view_tutorials, null);
        }
        else {
            gridView = (View) convertView;
        }

        //15 16 24 videoView

        VideoView vd1=gridView.findViewById(R.id.videoView);
        TextView tvposteddate= gridView.findViewById(R.id.textView15);
        TextView tvtitle= gridView.findViewById(R.id.textView16);
        TextView tvdetails= gridView.findViewById(R.id.textView24);
        TextView username= gridView.findViewById(R.id.username);
        ImageView uimgg= gridView.findViewById(R.id.userimg);


        tvposteddate.setText(v_date[i]);
        tvtitle.setText(title[i]);
        tvdetails.setText(description[i]);
        username.setText(uname[i]);

        SharedPreferences sh= PreferenceManager.getDefaultSharedPreferences(context);
        String url="http://"+ sh.getString("ip","")+":5050"+ video_name[i];
        vd1.setVideoURI(Uri.parse(url));

//
//        vd1 = (VideoView) findViewById(R.id.VideoView);
        vd1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                VideoView v=(VideoView) view;
                v.start();
            }
        });



        String url2 = "http://" + sh.getString("ip","") + ":5050" + uimg[i];
        Picasso.with(context).load(url2).into(uimgg);

        return gridView;
    }

}
