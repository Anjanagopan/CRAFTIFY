package com.example.craftify;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class pk_payment extends AppCompatActivity implements View.OnClickListener {
    String[]bank={"SBI","UNION","BB"};
    Spinner sp;
    EditText edpin;
    Button btp;
    TextView tvw;
    EditText ed1;
    EditText ed2;
    EditText ed3;
    EditText ed4;
    EditText ed5;
    EditText ed6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pk_payment);
        sp=(Spinner) findViewById(R.id.spinner);
        edpin=(EditText) findViewById(R.id.tvaccount);
        tvw=(TextView) findViewById(R.id.textView34);
        ed1=(EditText) findViewById(R.id.editTextTextPersonName4);
        ed2=(EditText) findViewById(R.id.editTextTextPersonName5);
        ed3=(EditText) findViewById(R.id.editTextTextPersonName6);
        ed4=(EditText) findViewById(R.id.editTextTextPersonName7);
        ed5=(EditText) findViewById(R.id.editTextTextPersonName8);
        ed6=(EditText) findViewById(R.id.editTextTextPersonName9);
        btp=(Button) findViewById(R.id.bttpurchase);
        btp.setOnClickListener(this);

        ArrayAdapter<String> adpt=new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,bank);
        sp.setAdapter(adpt);
    }

    @Override
    public void onClick(View view) {
        SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        String hu = sh.getString("ip", "");


        String url = "http://" + hu + ":5050/and_product_buy";


        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //  Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();

                        // response
                        try {
                            JSONObject jsonObj = new JSONObject(response);
                            if (jsonObj.getString("status").equalsIgnoreCase("ok")) {

                                Toast.makeText(pk_payment.this, "Payment Completed", Toast.LENGTH_SHORT).show();
                                Intent ins = new Intent(getApplicationContext(), UserHome.class);
                                startActivity(ins);
                            }
                            else if(jsonObj.getString("status").equalsIgnoreCase("low")){
                                Toast.makeText(pk_payment.this, "Low Balance", Toast.LENGTH_SHORT).show();

                            } else if(jsonObj.getString("status").equalsIgnoreCase("exist")){
                                Toast.makeText(pk_payment.this, "Already You have Active Package", Toast.LENGTH_SHORT).show();

                            }
                            else {
                                Toast.makeText(getApplicationContext(), "No data....", Toast.LENGTH_LONG).show();
                            }

                        } catch (Exception e) {
                            Toast.makeText(getApplicationContext(), "Error" + e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // error
                        Toast.makeText(getApplicationContext(), "eeeee" + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                Map<String, String> params = new HashMap<String, String>();


                params.put("lid", sh.getString("lid",""));
                params.put("bank", sp.getSelectedItem().toString());
                params.put("accpin", edpin.getText().toString());
                params.put("total", sh.getString("amount",""));
                params.put("pkid", sh.getString("pkid",""));
                params.put("name", ed1.getText().toString());
                params.put("phone", ed2.getText().toString());
                params.put("place", ed3.getText().toString());
                params.put("post", ed4.getText().toString());
                params.put("pincode", ed5.getText().toString());
                params.put("nearplace", ed6.getText().toString());
                params.put("selerid", sh.getString("sellerid",""));
                params.put("pid", sh.getString("pid",""));
                return params;
            }
        };

        int MY_SOCKET_TIMEOUT_MS = 100000;

        postRequest.setRetryPolicy(new DefaultRetryPolicy(
                MY_SOCKET_TIMEOUT_MS,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(postRequest);

    }
}