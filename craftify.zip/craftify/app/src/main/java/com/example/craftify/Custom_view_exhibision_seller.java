package com.example.craftify;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.VideoView;

public class Custom_view_exhibision_seller extends BaseAdapter {
    String[] exhibition_id,e_name,e_date,e_starttime,e_endtime;
    Context context;

    public Custom_view_exhibision_seller(Context applicationContext, String[] exhibition_id, String[]  e_name, String[]  e_date, String[]  e_starttime, String[]  e_endtime) {
        this.context = applicationContext;
        this.exhibition_id = exhibition_id;
        this.e_date = e_date;
        this.e_name = e_name;
        this.e_starttime = e_starttime;
        this.e_endtime = e_endtime;
    }

    @Override
    public int getCount() {
        return e_endtime.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup viewGroup) {
        LayoutInflater inflator = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View gridView;
        if (convertView == null) {
            gridView = new View(context);
            gridView = inflator.inflate(R.layout.cust_ex, null);
        }
        else {
            gridView = (View) convertView;
        }

        //15 16 24 videoView

        VideoView vd1=gridView.findViewById(R.id.videoView);
        TextView ename= gridView.findViewById(R.id.textView15);
        TextView edate= gridView.findViewById(R.id.textView16);
        TextView est= gridView.findViewById(R.id.textView25);

        TextView eet= gridView.findViewById(R.id.textView24);
        TextView btapply= gridView.findViewById(R.id.btapply);
        btapply.setTag(i);
        btapply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos= (int) view.getTag();
                SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(context);
                SharedPreferences.Editor ed=sh.edit();
                ed.putString("exibid",exhibition_id[pos]);

                ed.commit();
                Intent ij = new Intent(context,slr_view_products.class);
                ij.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(ij);
//                Toast.makeText(context, "Successfully Send", Toast.LENGTH_SHORT).show();

            }
        });

//        ename.setTextColor(Color);
        ename.setText(e_name[i]);
        edate.setText(e_date[i]);
        est.setText("Start at:"+e_starttime[i]);
        eet.setText("End at  :"+e_endtime[i]);





        return gridView;
    }

}
