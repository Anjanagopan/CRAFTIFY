package com.example.craftify;

import static android.app.Notification.*;
import static android.media.RingtoneManager.getDefaultUri;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import android.annotation.TargetApi;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;

import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.StrictMode;
import android.preference.PreferenceManager;

import android.util.Log;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

public class notiservise extends Service {
Handler hd;
String[] tit,noti,date;
String namespace="http://connection/";//viewNot($type)
String method="ViewEmergency";
String soapaction="http://connection/ViewEmergency";
String url="";
	@Override
	public IBinder onBind(Intent arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@TargetApi(Build.VERSION_CODES.GINGERBREAD)
	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		
try {
			
			if(Build.VERSION.SDK_INT>9) {
				StrictMode.ThreadPolicy policy=new StrictMode.ThreadPolicy.Builder().permitAll().build();
				StrictMode.setThreadPolicy(policy);
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
		hd=new Handler();
		hd.post(r);
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		hd.removeCallbacks(r);
	}
	public Runnable r=new Runnable() {
		
		@Override
		public void run() {
			// TODO Auto-generated method stub
			SimpleDateFormat df=new SimpleDateFormat("yyy-MM-dd");
			String curdate=df.format(new java.util.Date());

			SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
			Editor ed=sh.edit();
			String hu = sh.getString("ip", "");
			String url = "http://" + hu + ":5050/user_subscription";
			RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
			StringRequest postRequest = new StringRequest(Request.Method.POST, url,
					new Response.Listener<String>() {
						@RequiresApi(api = Build.VERSION_CODES.O)
						@Override
						public void onResponse(String response) {
							//  Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();

							// response
							try {
								JSONObject jsonObj = new JSONObject(response);
								if (jsonObj.getString("status").equalsIgnoreCase("ok")) {
									String day=jsonObj.getString("day");



//									Toast.makeText(notiservise.this, "succccccc-----------"+day, Toast.LENGTH_SHORT).show();

									ed.putString("day", day);
									ed.commit();


									if(day.equalsIgnoreCase("exeed")) {
										notis();
									}
//SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
//									SharedPreferences.Editor ed = sh.edit();
//									ed.putString("lid", jsonObj.getString("lid"));
//									ed.putString("uname", jsonObj.getString("name"));
//									ed.putString("photo", jsonObj.getString("photo"));
////                                    ed.putString("t1lmid", "0");
//
//									ed.commit();
//
//									Intent ii = new Intent(getApplicationContext(), LocationService.class);
//									startService(ii);
//									Intent iii = new Intent(getApplicationContext(), notiservise.class);
//									startService(iii);
//									Intent i = new Intent(getApplicationContext(), Home.class);
//									startActivity(i);
								}


								// }
								else {
									Toast.makeText(getApplicationContext(), "Not found", Toast.LENGTH_LONG).show();
								}

							} catch (Exception e) {
								Toast.makeText(getApplicationContext(), "Error" + e.getMessage().toString(), Toast.LENGTH_SHORT).show();
							}
						}
					},
					new Response.ErrorListener() {
						@Override
						public void onErrorResponse(VolleyError error) {
							// error
							Toast.makeText(getApplicationContext(), "eeeee" + error.toString(), Toast.LENGTH_SHORT).show();
						}
					}
			) {
				@Override
				protected Map<String, String> getParams() {
					SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
					Map<String, String> params = new HashMap<String, String>();


					params.put("lid", sh.getString("lid", ""));
//					params.put("lastmsgid", sh.getString("t1lmid",""));

					return params;
				}
			};

			int MY_SOCKET_TIMEOUT_MS = 100000;

			postRequest.setRetryPolicy(new DefaultRetryPolicy(
					MY_SOCKET_TIMEOUT_MS,
					DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
					DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
			requestQueue.add(postRequest);
		
			
			hd.postDelayed(r, 5000);
			
		}
	};
	
	@RequiresApi(api = Build.VERSION_CODES.O)
	public void notis() {

		SharedPreferences sh=PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

		final String CHANNEL_ID = "channel123";
		final String CHANNEL_NAME = "my notification";
		final String CHANNEL_DESCRIPTION = "Test";

		NotificationChannel channel = new NotificationChannel(
				CHANNEL_ID,
				CHANNEL_NAME,
				NotificationManager.IMPORTANCE_DEFAULT
		);
		long [] VIBRATE_PATTERN = { 0 , 500 } ;
		channel.setLightColor(R.color.purple_200 ) ;
		channel.setVibrationPattern(VIBRATE_PATTERN) ;
		channel.enableVibration( true );
		channel.setDescription(CHANNEL_DESCRIPTION);
		Uri alarmSound = getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
		Intent notificationIntent = new Intent(getApplicationContext(), UserHome.class);
		notificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);

		int requestID = (int) System.currentTimeMillis();

//**edit this line to put requestID as requestCode**
		PendingIntent contentIntent = PendingIntent.getActivity(this, requestID,notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);

		NotificationCompat.Builder mBuilder =
				new NotificationCompat.Builder(this, CHANNEL_ID)
						.setSmallIcon(R.drawable.ic_notifications_black_24dp)
						.setContentTitle("Hello, attention!")
						.setContentText("Subscribe packages for view tutorials")
						.setPriority(NotificationCompat.PRIORITY_DEFAULT)
				;

		mBuilder.setSound(alarmSound);
		mBuilder.setContentIntent(contentIntent);
		NotificationManager manager = getSystemService(NotificationManager.class);
		manager.createNotificationChannel(channel);

		NotificationManagerCompat mNotificationManager = NotificationManagerCompat.from(this);
		mNotificationManager.notify(1, mBuilder.build());

	}

}
