package com.example.craftify;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class view_profile extends AppCompatActivity implements View.OnClickListener {


    TextView td_name, td_gender, td_email, td_phone, td_house, td_post, td_city, td_pin;
    ImageView img, back;
    Button bt_edit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_profile);

        td_name = (TextView) findViewById(R.id.tv1);
        td_gender = (TextView) findViewById(R.id.tv2);
        td_email = (TextView) findViewById(R.id.tv7);
        td_phone = (TextView) findViewById(R.id.tv8);
//        td_house = (TextView) findViewById(R.id.tv3);
        td_post = (TextView) findViewById(R.id.tv4);
        td_city = (TextView) findViewById(R.id.tv5);
        td_pin = (TextView) findViewById(R.id.tv6);
        img = (ImageView) findViewById(R.id.imageView2);
        bt_edit = (Button) findViewById(R.id.b1);
//        back = (ImageView) findViewById(R.id.back_btn);
        bt_edit.setOnClickListener(this);
//        back.setOnClickListener(this);


        SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        String hu = sh.getString("ip", "");
        String url = "http://" + hu + ":5050/and_view_profile";

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //  Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();

                        // response
                        try {
                            JSONObject jsonObja = new JSONObject(response);
                            if (jsonObja.getString("status").equalsIgnoreCase("ok")) {

                                JSONObject jsonObj= jsonObja.getJSONObject("data");

                                String name = jsonObj.getString("s_name");
                                td_name.setText(name);
                                td_name.setTextColor(Color.WHITE);

                                String gen = jsonObj.getString("s_gender");
                                td_gender.setText(gen);
                                td_gender.setTextColor(Color.WHITE);

                                String email = jsonObj.getString("s_email");
                                td_email.setText(email);
                                td_email.setTextColor(Color.WHITE);

                                String phn = jsonObj.getString("s_phone");
                                td_phone.setText(phn);
                                td_phone.setTextColor(Color.WHITE);

//                                String house = jsonObj.getString("house");
//                                td_house.setText(house);
//                                td_house.setTextColor(Color.BLACK);

                                String pst = jsonObj.getString("s_place");
                                td_post.setText(pst);
                                td_post.setTextColor(Color.WHITE);

                                String cty = jsonObj.getString("s_post");
                                td_city.setText(cty);
                                td_city.setTextColor(Color.WHITE);

                                String imge = jsonObj.getString("s_image");
                                SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                                String ip = sh.getString("ip", "");
                                String url = "http://" + ip + ":5050" + imge;
                                Picasso.with(getApplicationContext()).load(url).into(img);


                                String pin = jsonObj.getString("s_pincode");
                                td_pin.setText(pin);
                                td_pin.setTextColor(Color.WHITE);


                            } else {
                                Toast.makeText(getApplicationContext(), "Not found", Toast.LENGTH_LONG).show();
                            }

                        } catch (Exception e) {
                            Toast.makeText(getApplicationContext(), "Error" + e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // error
                        Toast.makeText(getApplicationContext(), "eeeee" + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                Map<String, String> params = new HashMap<String, String>();


                params.put("lid", sh.getString("lid", ""));

                return params;
            }
        };

        int MY_SOCKET_TIMEOUT_MS = 100000;

        postRequest.setRetryPolicy(new DefaultRetryPolicy(
                MY_SOCKET_TIMEOUT_MS,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(postRequest);
    }

    @Override
    public void onClick(View view) {
        if (view == bt_edit) {
            Intent ij = new Intent(getApplicationContext(), edit_profilepage.class);
            startActivity(ij);
        }

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}