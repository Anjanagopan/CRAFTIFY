package com.example.craftify;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Custom_view_packages extends BaseAdapter {
    String[] package_id,p_name,p_amount,p_details;
    Context context;

    public Custom_view_packages(Context applicationContext, String[] package_id, String[] p_name, String[]  p_amount, String[]  p_details) {
        this.context = applicationContext;
        this.package_id = package_id;
        this.p_name = p_name;
        this.p_details = p_details;
        this.p_amount = p_amount;

    }

    @Override
    public int getCount() {
        return package_id.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup viewGroup) {
        LayoutInflater inflator = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View gridView;
        if (convertView == null) {
            gridView = new View(context);
            gridView = inflator.inflate(R.layout.custom_user_view_packages, null);
        }
        else {
            gridView = (View) convertView;
        }

        //15 16 24 videoView


        TextView pkname= gridView.findViewById(R.id.pkname);
        TextView pkamout= gridView.findViewById(R.id.pkamout);
        TextView pkdes= gridView.findViewById(R.id.pkdesc);


        Button btapply= gridView.findViewById(R.id.btbuy);
        btapply.setTag(i);
        btapply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos= (int) view.getTag();
                SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(context);
                SharedPreferences.Editor ed=sh.edit();
                ed.putString("pkid",package_id[pos]);
                ed.putString("amount",p_amount[pos]);
                ed.commit();
                Intent ij = new Intent(context, Payment.class);
                ij.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(ij);
//                Toast.makeText(context, "Successfully Send", Toast.LENGTH_SHORT).show();

            }
        });

//        ename.setTextColor(Color);
        pkname.setText(p_name[i]);
        pkamout.setText(p_amount[i]);
        pkdes.setText(p_details[i]);





        return gridView;
    }

}
