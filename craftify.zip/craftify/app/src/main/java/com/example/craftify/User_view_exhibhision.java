package com.example.craftify;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class User_view_exhibhision extends AppCompatActivity {

    ListView lvs;
    String [] exhibition_id,e_name,e_date,e_starttime,e_endtime;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_view_exhibhision);
        lvs=(ListView) findViewById(R.id.lvs);

        SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        String hu = sh.getString("ip", "");
        String url = "http://" + hu + ":5050/and_user_view_exhibition";

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //  Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();

                        // response
                        try {
                            JSONObject jsonObja = new JSONObject(response);
                            if (jsonObja.getString("status").equalsIgnoreCase("ok")) {

                                JSONArray jsonObj= jsonObja.getJSONArray("data");

                                exhibition_id=new String[jsonObj.length()];
                                e_name=new String[jsonObj.length()];
                                e_date=new String[jsonObj.length()];
                                e_starttime=new String[jsonObj.length()];
                                e_endtime=new String[jsonObj.length()];

                                for(int i=0;i<exhibition_id.length;i++)
                                {
                                    JSONObject jk= jsonObj.getJSONObject(i);
                                    exhibition_id[i]=jk.getString("exhibition_id");
                                    e_name[i]=jk.getString("e_name");
                                    e_date[i]=jk.getString("e_date");
                                    e_starttime[i]=jk.getString("e_starttime");
                                    e_endtime[i]=jk.getString("e_endtime");

                                }

                                lvs.setAdapter(new Custom_view_exhibision(getApplicationContext(), exhibition_id,e_name,e_date,e_starttime,e_endtime));


                            } else {
                                Toast.makeText(getApplicationContext(), "Not found", Toast.LENGTH_LONG).show();
                            }

                        } catch (Exception e) {
                            Toast.makeText(getApplicationContext(), "Error" + e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // error
                        Toast.makeText(getApplicationContext(), "eeeee" + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                Map<String, String> params = new HashMap<String, String>();


                params.put("lid", sh.getString("lid", ""));

                return params;
            }
        };

        int MY_SOCKET_TIMEOUT_MS = 100000;

        postRequest.setRetryPolicy(new DefaultRetryPolicy(
                MY_SOCKET_TIMEOUT_MS,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(postRequest);

    }
}