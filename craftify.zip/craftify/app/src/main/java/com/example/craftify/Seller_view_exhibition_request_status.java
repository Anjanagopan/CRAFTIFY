package com.example.craftify;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Seller_view_exhibition_request_status extends AppCompatActivity {
    ListView lvs;
    String [] product_id,product_name,photo,exname,exdate,exfromtime,extotime,status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seller_view_exhibition_request_status);
        lvs=(ListView) findViewById(R.id.lst);

        SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        String hu = sh.getString("ip", "");
        String url = "http://" + hu + ":5050/seller_view_req_status";

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //  Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();

                        // response
                        try {
                            JSONObject jsonObja = new JSONObject(response);
                            if (jsonObja.getString("status").equalsIgnoreCase("ok")) {

                                JSONArray jsonObj= jsonObja.getJSONArray("data");
                                product_id=new String[jsonObj.length()];
                                product_name=new String[jsonObj.length()];

                                photo=new String[jsonObj.length()];
                                exname=new String[jsonObj.length()];
                                exdate=new String[jsonObj.length()];
                                exfromtime=new String[jsonObj.length()];
                                extotime=new String[jsonObj.length()];
                                status=new String[jsonObj.length()];


                                for(int i=0;i<product_id.length;i++)
                                {

//                                    `e_name`,`e_date`,`e_starttime`,`e_endtime`
                                    JSONObject jk= jsonObj.getJSONObject(i);
                                    product_id[i]=jk.getString("product_id");
                                    product_name[i]=jk.getString("product_name");
                                    photo[i]=jk.getString("photo");
                                    exname[i]=jk.getString("e_name");
                                    exdate[i]=jk.getString("e_date");
                                    exfromtime[i]=jk.getString("e_starttime");
                                    extotime[i]=jk.getString("e_endtime");
                                    status[i]=jk.getString("status");
                                }

                                lvs.setAdapter(new Custom_seller_view_exhibition_request(getApplicationContext(),product_id,product_name,photo,exname,exdate,exfromtime,extotime,status));


                            } else {
                                Toast.makeText(getApplicationContext(), "Not found", Toast.LENGTH_LONG).show();
                            }

                        } catch (Exception e) {
                            Toast.makeText(getApplicationContext(), "Error" + e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // error
                        Toast.makeText(getApplicationContext(), "eeeee" + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                Map<String, String> params = new HashMap<String, String>();


                params.put("lid", sh.getString("lid", ""));

                return params;
            }
        };

        int MY_SOCKET_TIMEOUT_MS = 100000;

        postRequest.setRetryPolicy(new DefaultRetryPolicy(
                MY_SOCKET_TIMEOUT_MS,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(postRequest);

    }
}