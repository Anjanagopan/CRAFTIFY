package com.example.craftify;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.craftify.databinding.ActivityUserHome2Binding;
import com.google.android.material.navigation.NavigationBarView;

public class UserHome extends AppCompatActivity implements NavigationBarView.OnItemSelectedListener, View.OnClickListener {

    private ActivityUserHome2Binding binding;
    Button btexh,bttutorial,btpur_history,btallproducts;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityUserHome2Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        BottomNavigationView navView = findViewById(R.id.nav_view);
        navView.setOnItemSelectedListener(this);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications)
                .build();
//        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_user_home2);
//        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
//        NavigationUI.setupWithNavController(binding.navView, navController);

        btexh=(Button) findViewById(R.id.btexhibtion);
        bttutorial=(Button) findViewById(R.id.bttutorials);
        btpur_history=(Button) findViewById(R.id.bthistory);
        btallproducts=(Button) findViewById(R.id.btallproducts);


        btexh.setOnClickListener(this);
        bttutorial.setOnClickListener(this);
        btpur_history.setOnClickListener(this);
        btallproducts.setOnClickListener(this);


        SharedPreferences sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        String day=sh.getString("day","").toString();
        if(day.equalsIgnoreCase("exeed"))
        {

            bttutorial.setVisibility(View.INVISIBLE);
        }
        else {
            bttutorial.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id=item.getItemId();
        if(id==R.id.navigation_profile){
            startActivity(new Intent(getApplicationContext(),user_profile.class));
        }else if(id==R.id.navigation_Pakages){
            startActivity(new Intent(getApplicationContext(),User_view_pakages.class));
        }else if(id==R.id.navigation_logout){
            Intent ijser = new Intent(getApplicationContext(), notiservise.class);
            stopService(ijser);
            startActivity(new Intent(getApplicationContext(),login.class));
        }
        return true;
    }

    @Override
    public void onClick(View view) {
        if(view==btexh)
        {
            startActivity(new Intent(getApplicationContext(),User_view_exhibhision.class));
        }if(view==bttutorial)
        {
            startActivity(new Intent(getApplicationContext(),User_view_toutorials.class));
        }if(view==btpur_history)
        {
            startActivity(new Intent(getApplicationContext(),user_view_poduct_purchase_history.class));
        }if(view==btallproducts)
        {
            startActivity(new Intent(getApplicationContext(),User_view_all_product.class));
        }

    }
}