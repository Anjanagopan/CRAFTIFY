package com.example.craftify;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class custom_view_product extends BaseAdapter  {
   String[] product_id,product_name,product_count,product_price,product_details,photo;
    Context context;

    public custom_view_product(Context applicationContext, String[] product_id, String[] product_name, String[] product_count, String[] product_price, String[] product_details, String[] photo) {
        this.context = applicationContext;
        this.product_id = product_id;
        this.product_name = product_name;
        this.product_count = product_count;
        this.product_price = product_price;
        this.product_details = product_details;
        this.photo = photo;

    }

    @Override
    public int getCount() {
        return photo.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup viewGroup) {
        LayoutInflater inflator = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View gridView;
        if (convertView == null) {
            gridView = new View(context);
            gridView = inflator.inflate(R.layout.customproduct, null);

        } else {
            gridView = (View) convertView;

        }

        TextView tvname = (TextView) gridView.findViewById(R.id.textView15);
        TextView tvqty = (TextView) gridView.findViewById(R.id.textView16);
        TextView tvdetails = (TextView) gridView.findViewById(R.id.textView18);
        TextView tvprice = (TextView) gridView.findViewById(R.id.textView19);

        ImageView iv = (ImageView) gridView.findViewById(R.id.imageView4);
        ImageView imgrate = (ImageView) gridView.findViewById(R.id.imgrate);
//        imgrate.setVisibility(View.INVISIBLE);
        imgrate.setTag(i);
        imgrate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos= (int) view.getTag();
                SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(context);
                SharedPreferences.Editor ed = sh.edit();
                ed.putString("pid", product_id[pos]);
                ed.commit();



                Intent ij = new Intent(context, view_rating.class);
                ij.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(ij);


            }
        });
        tvname.setText(product_name[i]);
        tvqty.setText(product_count[i]);
        tvprice.setText(product_price[i]);
        tvdetails.setText(product_details[i]);

        SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(context.getApplicationContext());
        String ip = sh.getString("ip", "");
        String url = "http://" + ip + ":5050" + photo[i];
        Picasso.with(context.getApplicationContext()).load(url).into(iv);






        return gridView;
    }


}
