package com.example.craftify;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.Base64;

public class Custom_view_winner extends BaseAdapter {
    String[] selid, sellname, sellimg;
    Context context;

    public Custom_view_winner(Context applicationContext, String[] sellid, String[] sellname, String[] sellimg) {
        this.context = applicationContext;
        this.selid = sellid;
        this.sellname = sellname;
        this.sellimg = sellimg;


    }

    @Override
    public int getCount() {
        return sellimg.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup viewGroup) {
        LayoutInflater inflator = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View gridView;
        if (convertView == null) {
            gridView = new View(context);
            gridView = inflator.inflate(R.layout.custom_user_view_winner, null);

        } else {
            gridView = (View) convertView;

        }

        TextView tvname = (TextView) gridView.findViewById(R.id.winnername);

        ImageView iv = (ImageView) gridView.findViewById(R.id.winnerimg);

        tvname.setText(sellname[i]);

        SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(context.getApplicationContext());
        String ip = sh.getString("ip", "");
        String url = "http://" + ip + ":5050" + sellimg[i];
        Picasso.with(context.getApplicationContext()).load(url).into(iv);


        return gridView;
    }
}
