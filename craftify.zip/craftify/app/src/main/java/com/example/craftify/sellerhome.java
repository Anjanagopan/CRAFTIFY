package com.example.craftify;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;

import androidx.annotation.NonNull;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;

import com.example.craftify.databinding.ActivitySellerhomeBinding;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class sellerhome extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private AppBarConfiguration mAppBarConfiguration;
    private ActivitySellerhomeBinding binding;
ListView lv;
    String [] exhibition_id,e_name,e_date,e_starttime,e_endtime;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivitySellerhomeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.appBarSellerhome.toolbar);
        binding.appBarSellerhome.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow)
                .setOpenableLayout(drawer)
                .build();
//        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_sellerhome);
//        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
//        NavigationUI.setupWithNavController(navigationView, navController);
        lv=(ListView)findViewById(R.id.lv);
        navigationView.setNavigationItemSelectedListener(this);
        pp();
    }
    public void pp(){
        SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        String hu = sh.getString("ip", "");
        String url = "http://" + hu + ":5050/and_user_view_exhibition";

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //  Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();

                        // response
                        try {
                            JSONObject jsonObja = new JSONObject(response);
                            if (jsonObja.getString("status").equalsIgnoreCase("ok")) {

                                JSONArray jsonObj= jsonObja.getJSONArray("data");

                                exhibition_id=new String[jsonObj.length()];
                                e_name=new String[jsonObj.length()];
                                e_date=new String[jsonObj.length()];
                                e_starttime=new String[jsonObj.length()];
                                e_endtime=new String[jsonObj.length()];

                                for(int i=0;i<exhibition_id.length;i++)
                                {
                                    JSONObject jk= jsonObj.getJSONObject(i);
                                    exhibition_id[i]=jk.getString("exhibition_id");
                                    e_name[i]=jk.getString("e_name");
                                    e_date[i]=jk.getString("e_date");
                                    e_starttime[i]=jk.getString("e_starttime");
                                    e_endtime[i]=jk.getString("e_endtime");

                                }

                                lv.setAdapter(new Custom_view_exhibision_seller(getApplicationContext(), exhibition_id,e_name,e_date,e_starttime,e_endtime));


                            } else {
                                Toast.makeText(getApplicationContext(), "Not found", Toast.LENGTH_LONG).show();
                            }

                        } catch (Exception e) {
                            Toast.makeText(getApplicationContext(), "Error" + e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // error
                        Toast.makeText(getApplicationContext(), "eeeee" + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                Map<String, String> params = new HashMap<String, String>();


                params.put("lid", sh.getString("lid", ""));

                return params;
            }
        };

        int MY_SOCKET_TIMEOUT_MS = 100000;

        postRequest.setRetryPolicy(new DefaultRetryPolicy(
                MY_SOCKET_TIMEOUT_MS,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(postRequest);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.sellerhome, menu);
        return true;
    }

//    @Override
//    public boolean onSupportNavigateUp() {
//        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_sellerhome);
//        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
//                || super.onSupportNavigateUp();
//    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id=item.getItemId();
        if(id==R.id.nav_home)
        {
            Intent ij=new Intent(getApplicationContext(),view_profile.class);
            startActivity(ij);
        }

        if(id==R.id.nav_view)
        {
            Intent ij=new Intent(getApplicationContext(),view_product.class);
            startActivity(ij);
        }
        if(id==R.id.nav_add)
        {
            Intent ij=new Intent(getApplicationContext(),product_add.class);
            startActivity(ij);
        }
        if(id==R.id.nav_ADD_TUT)
        {
            Intent ij=new Intent(getApplicationContext(),video_upload.class);
            startActivity(ij);
        }
        if(id==R.id.nav_VIEW_TUT)
        {
            Intent ij=new Intent(getApplicationContext(),vediolist.class);
            startActivity(ij);
        }
        if(id==R.id.nav_log)
        {
            Intent ij=new Intent(getApplicationContext(),login.class);
            startActivity(ij);
        }
        if(id==R.id.nav_ex)
        {
            Intent ij=new Intent(getApplicationContext(),View_exhibition.class);
            startActivity(ij);
        }if(id==R.id.nav_ex_req)
        {
            Intent ij=new Intent(getApplicationContext(),Seller_view_exhibition_request_status.class);
            startActivity(ij);
        }if(id==R.id.nav_booking)
        {
            Intent ij=new Intent(getApplicationContext(),view_booking.class);
            startActivity(ij);
        }
        return false;
    }
}