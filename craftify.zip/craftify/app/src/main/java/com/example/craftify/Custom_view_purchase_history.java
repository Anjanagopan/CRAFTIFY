package com.example.craftify;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class Custom_view_purchase_history extends BaseAdapter {
    String[] product_id, product_name, product_count, product_price, product_details, photo, sellerid,sellname,sellimg,selldate;
    Context context;

    public Custom_view_purchase_history(Context applicationContext, String[] product_id, String[] product_name, String[] product_count, String[] product_price, String[] product_details, String[] photo, String[] sellerid, String[]sellname, String[]sellimg, String[]selldate) {
        this.context = applicationContext;
        this.product_id = product_id;
        this.product_name = product_name;
        this.product_count = product_count;
        this.product_price = product_price;
        this.product_details = product_details;
        this.photo = photo;
        this.sellerid = sellerid;
        this.sellname = sellname;
        this.sellimg = sellimg;
        this.selldate = selldate;

    }

    @Override
    public int getCount() {
        return photo.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup viewGroup) {
        LayoutInflater inflator = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View gridView;
        if (convertView == null) {
            gridView = new View(context);
            gridView = inflator.inflate(R.layout.custom_user_view_purchase_history, null);

        } else {
            gridView = (View) convertView;

        }

        TextView tvname = (TextView) gridView.findViewById(R.id.textView15);
        TextView tvqty = (TextView) gridView.findViewById(R.id.textView16);
        TextView tvdetails = (TextView) gridView.findViewById(R.id.textView18);
        TextView tvprice = (TextView) gridView.findViewById(R.id.textView19);
        TextView sellnamee = (TextView) gridView.findViewById(R.id.sellname);

        ImageView iv = (ImageView) gridView.findViewById(R.id.imageView4);
        ImageView selimgg = (ImageView) gridView.findViewById(R.id.selimg);
        ImageView imgrate = (ImageView) gridView.findViewById(R.id.imgrate);
        imgrate.setTag(i);
        imgrate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = (int) view.getTag();
                SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(context);
                SharedPreferences.Editor ed = sh.edit();
                ed.putString("pid", product_id[pos]);
                ed.commit();


                Intent ij = new Intent(context, user_send_rating.class);
                ij.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(ij);


            }
        });

        tvname.setText(product_name[i]);
        tvqty.setText(product_count[i]);
        tvprice.setText(product_price[i]);
        tvdetails.setText(product_details[i]);
        sellnamee.setText(sellname[i]);

        SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(context.getApplicationContext());
        String ip = sh.getString("ip", "");
        String url = "http://" + ip + ":5050" + photo[i];
        Picasso.with(context.getApplicationContext()).load(url).into(iv);

        String url2 = "http://" + ip + ":5050" + sellimg[i];
        Picasso.with(context.getApplicationContext()).load(url2).into(selimgg);


        return gridView;
    }
}
