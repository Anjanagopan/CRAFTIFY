package com.example.craftify;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class custom_view_exhibition extends BaseAdapter  {
   String[] exhibition_id,e_name,e_date,e_starttime,e_endtime;
    Context context;

    public custom_view_exhibition(Context applicationContext, String[] exhibition_id, String[]  e_name, String[]  e_date, String[]  e_starttime, String[]  e_endtime) {
        this.context = applicationContext;
        this.exhibition_id = exhibition_id;
        this.e_date = e_date;
        this.e_name = e_name;
        this.e_starttime = e_starttime;
        this.e_endtime = e_endtime;
    }

    @Override
    public int getCount() {
        return e_endtime.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup viewGroup) {
        LayoutInflater inflator = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View gridView;
        if (convertView == null) {
            gridView = new View(context);
            gridView = inflator.inflate(R.layout.customexhibition, null);
        }
        else {
            gridView = (View) convertView;
        }

        //15 16 24 videoView

        VideoView vd1=gridView.findViewById(R.id.videoView);
        TextView ename= gridView.findViewById(R.id.textView15);
        TextView edate= gridView.findViewById(R.id.textView16);
        TextView est= gridView.findViewById(R.id.textView25);

        TextView eet= gridView.findViewById(R.id.textView24);
        Button btapply= gridView.findViewById(R.id.btapply);
        btapply.setTag(i);
        btapply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos= (int) view.getTag();


                SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(context);
                SharedPreferences.Editor ed=sh.edit();
                ed.putString("exb",exhibition_id[pos]);

                ed.commit();
                Intent ij = new Intent(context, Choose_exhibtion_produts.class);
                ij.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(ij);

            }
        });

        Button btwinners= gridView.findViewById(R.id.btwinners);
        btwinners.setTag(i);
        btwinners.setVisibility(View.INVISIBLE);
        btwinners.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos= (int) view.getTag();
                SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(context);
                SharedPreferences.Editor ed=sh.edit();
                ed.putString("exb",exhibition_id[pos]);

                ed.commit();
                Intent ij = new Intent(context, view_winner.class);
                ij.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(ij);
//                Toast.makeText(context, "Successfully Send", Toast.LENGTH_SHORT).show();


            }
        });



//        ename.setTextColor(Color);
        ename.setText(e_name[i]);
        edate.setText(e_date[i]);
        est.setText("Start at:"+e_starttime[i]);
        eet.setText("End at  :"+e_endtime[i]);





        return gridView;
    }


}
