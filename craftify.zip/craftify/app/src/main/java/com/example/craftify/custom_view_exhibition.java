package com.example.craftify;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class custom_view_exhibition extends BaseAdapter  {
   String[] exhibition_id,e_name,e_date,e_starttime,e_endtime;
    Context context;

    public custom_view_exhibition(Context applicationContext, String[] exhibition_id, String[]  e_name, String[]  e_date, String[]  e_starttime, String[]  e_endtime) {
        this.context = applicationContext;
        this.exhibition_id = exhibition_id;
        this.e_date = e_date;
        this.e_name = e_name;
        this.e_starttime = e_starttime;
        this.e_endtime = e_endtime;
    }

    @Override
    public int getCount() {
        return e_endtime.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup viewGroup) {
        LayoutInflater inflator = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View gridView;
        if (convertView == null) {
            gridView = new View(context);
            gridView = inflator.inflate(R.layout.customexhibition, null);
        }
        else {
            gridView = (View) convertView;
        }

        //15 16 24 videoView

        VideoView vd1=gridView.findViewById(R.id.videoView);
        TextView ename= gridView.findViewById(R.id.textView15);
        TextView edate= gridView.findViewById(R.id.textView16);
        TextView est= gridView.findViewById(R.id.textView25);

        TextView eet= gridView.findViewById(R.id.textView24);
        TextView btapply= gridView.findViewById(R.id.btapply);
        btapply.setTag(i);
        btapply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos= (int) view.getTag();
                SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(context);
                String hu = sh.getString("ip", "");
                String url = "http://" + hu + ":5050/and__apply_exhibition";

                RequestQueue requestQueue = Volley.newRequestQueue(context);
                StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                //  Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();

                                // response
                                try {
                                    JSONObject jsonObj = new JSONObject(response);
                                    if (jsonObj.getString("status").equalsIgnoreCase("ok")) {
                                        Intent ij = new Intent(context, sellerhome.class);
                                            ij.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                            context.startActivity(ij);
                                        Toast.makeText(context, "Successfully Send", Toast.LENGTH_SHORT).show();

                                    } else {
                                        Toast.makeText(context, "Not found", Toast.LENGTH_LONG).show();
                                    }

                                } catch (Exception e) {
                                    Toast.makeText(context, "Error" + e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                // error
                                Toast.makeText(context, "eeeee" + error.toString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                ) {
                    @Override
                    protected Map<String, String> getParams() {
                        SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(context);
                        Map<String, String> params = new HashMap<String, String>();


                        params.put("lid", sh.getString("lid",""));
                        params.put("exid", exhibition_id[pos]);

                        return params;
                    }
                };

                int MY_SOCKET_TIMEOUT_MS = 100000;

                postRequest.setRetryPolicy(new DefaultRetryPolicy(
                        MY_SOCKET_TIMEOUT_MS,
                        DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
                requestQueue.add(postRequest);






            }
        });

//        ename.setTextColor(Color);
        ename.setText(e_name[i]);
        edate.setText(e_date[i]);
        est.setText("Start at:"+e_starttime[i]);
        eet.setText("End at  :"+e_endtime[i]);





        return gridView;
    }


}
