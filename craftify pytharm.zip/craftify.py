from flask import Flask, render_template, request, session, jsonify
from DBConnection import Db

app = Flask(__name__)
app.secret_key="h1"



@app.route('/')
def launching():
    return render_template('admin/main_index.html')

@app.route('/login')
def login():
    return render_template('admin/login_index.html')

@app.route('/login_post', methods=['post'])
def login_post():
   db=Db()
   uname = request.form['textfield']
   password = request.form['textfield2']
   ss=db.selectOne("select * from login WHERE username='"+uname+"'and password='"+password+"'")
   if ss is not None:
       session['lid']=ss['login_id']
       if ss ['type']=='admin':

            return render_template('admin/admin_index.html')
       # elif ss ['type']=='seller':
       #      return view_registered_seller_post
       # elif ss ['type']=='user':
       #      return view_users_post
       else:
            return '''<script>alert('Invalid User!');window.location='/login'</script>'''
   else:
       return '''<script>alert('Invalid User!');window.location='/login'</script>'''

@app.route('/package_management')
def package_management():
    return render_template('admin/package_management.html')

@app.route('/package_management_post', methods=['post'])
def package_management_post():
    db = Db()
    packagename = request.form['textfield']
    amount = request.form['textfield2']
    details = request.form['textfield3']

    db.insert("insert into package_model (p_name,p_amount,p_details) VALUES ('"+packagename+"','"+amount+"','"+details+"')")

    return 'ok..Packages added successfully'

@app.route('/exhibition_management')
def exhibition_management():
    return render_template('admin/exhibition_management.html')

@app.route('/exhibition_management_post', methods=['post'])
def exhibition_management_post():
    db = Db()
    exhibitionname = request.form['textfield']
    exhibitiondate = request.form['textfield2']
    starttime = request.form['textfield3']
    endtime = request.form['textfield4']
    db.insert("insert into exhibition_model (e_name,e_date,e_starttime,e_endtime) VALUES ('"+exhibitionname+"','"+exhibitiondate+"','"+starttime+"','"+endtime+"')")

    return 'ok..Exhibition added successfully'


@app.route('/view_approved_seller')
def view_approved_seller():
    db = Db()
    res = db.select("SELECT * FROM `login`,`seller_model` WHERE `seller_model`.`login_id`=`login`.`login_id` AND login.type = 'seller'")
    return render_template('admin/view_approved_seller.html',data = res)

@app.route('/view_approved_seller_post', methods=['post'])
def view_approved_seller_post():
    db = Db()
    sellername = request.form['textfield']
    res = db.select("SELECT * FROM `login`,`seller_model` WHERE `seller_model`.`login_id`=`login`.`login_id` AND login.type = 'seller' and  seller_model.s_name='"+sellername+"' ")
    print(res)
    return render_template('admin/view_approved_seller.html',data = res)

@app.route('/approve_seller/<s_id>')
def approve_seller(s_id):
    db = Db()
    db.update("update login set type = 'seller' where login_id = '"+str(s_id)+"'")
    return '''<script>alert('approved');window.location='/view_registered_seller'</script>'''

@app.route('/block_approved_seller/<s_id>')
def block_approved_seller(s_id):
    db = Db()
    print(s_id)
    db.update("update login set type = 'blocked' where login_id = '"+s_id+"'")
    return "OK"


@app.route('/view_packages')
def view_packages():
    db = Db()
    res = db.select("select * from package_model")
    print(res)
    return render_template('admin/view_packages.html', data=res)


@app.route('/view_package_post', methods=['post'])
def view_package_post():
    db = Db()
    res = db.select("select * from package_model")
    print(res)
    return render_template('admin/view_packages.html', data=res)

@app.route('/delete_package/<package_id>')
def delete_package(package_id):
    d = Db()
    qry = "delete from package_model where package_id='"+package_id+"'"
    res = d.delete(qry)
    return '''<script>alert('Deleted');window.location='/view_packages'</script>'''

@app.route('/edit_package/<package_id>')
def edit_package(package_id):
    d = Db()
    qry = "SELECT * FROM `package_model` WHERE `package_id`='"+str(package_id)+"'"
    res=d.selectOne(qry)
    return render_template('admin/edit_package.html',data=res)

@app.route('/edit_package_post', methods=['post'])
def edit_package_post():
    id=request.form['p_id']
    name=request.form['textfield']
    amount=request.form['textfield2']
    details=request.form['textfield3']
    d = Db()
    qry = "UPDATE package_model SET p_name='"+name+"',p_amount='"+amount+"',p_details='"+details+"' where package_id='"+str(id)+"' "
    res = d.update(qry)

    return '''<script>alert('updated');window.location='/view_packages'</script>'''

@app.route('/view_exhibition')
def view_exhibition():
    db = Db()
    res = db.select("select * from exhibition_model")
    print(res)
    return render_template('admin/view_exhibition.html', data=res)


@app.route('/view_exhibition_post', methods=['post'])
def view_exhibition_post():
    db = Db()
    res = db.select("select * from exhibition_model")
    print(res)
    return render_template('admin/view_exhibition.html', data=res)


@app.route('/edit_exhibition/<exhibition_id>')
def edit_exhibition(exhibition_id):
    d = Db()
    qry = "SELECT * FROM `exhibition_model` WHERE `exhibition_id`='"+str(exhibition_id)+"'"
    res=d.selectOne(qry)
    return render_template('admin/edit_exhibition.html',data=res)

@app.route('/edit_exhibition_post', methods=['post'])
def edit_exhibition_post():
    id=request.form['e_id']
    exhibitionname=request.form['textfield']
    exhibitiondate=request.form['textfield2']
    starttime = request.form['textfield3']
    endtime = request.form['textfield4']
    d = Db()
    qry = "UPDATE exhibition_model SET e_name='"+exhibitionname+"',e_date='"+exhibitiondate+"',e_starttime='"+starttime+"',e_endtime='"+endtime+"' where exhibition_id='"+str(id)+"' "
    res = d.update(qry)

    return '''<script>alert('updated');window.location='/view_exhibition'</script>'''

@app.route('/delete_exhibition/<exhibition_id>')
def delete_exhibition(exhibition_id):
    d = Db()
    qry = "delete from exhibition_model where exhibition_id='"+exhibition_id+"'"
    res = d.delete(qry)
    return '''<script>alert('Deleted');window.location='/view_exhibition'</script>'''



@app.route('/view_products')
def view_products():
    db = Db()
    res = db.select("select * from product_model ")
    print(res)
    qry2="SELECT * FROM `seller_model`"
    res2=db.select(qry2)
    return render_template('admin/view_products.html',data=res,data2=res2)

@app.route('/view_products_post', methods=['post'])
def view_products_post():
    db = Db()
    btn=request.form['button']
    print("===",btn)
    if btn=="Check":
        sid = request.form['sss']
        q="select * from product_model WHERE seller_id='"+sid+"'"
        r=db.select(q)
        print(q)
        return render_template('admin/view_products.html',data = r)
    if btn=="Search":
        productname = request.form['textfield']
        res = db.select("select * from product_model WHERE product_name='" + productname + "' ")
        print(res)
        return render_template('admin/view_products.html', data=res)


@app.route('/view_approved_seller_product/<v>')
def view_approved_seller_product(v):
    db = Db()
    res = db.select("select * from product_model where `seller_id`='"+v+"'")
    print(res)
    return render_template('admin/view_approved_seller_product.html', data=res)

@app.route('/view_approved_seller_product_post', methods=['post'])
def view_approved_seller_product_post():
    db = Db()
    productname = request.form['textfield']
    res = db.select("select * from product_model WHERE product_name='" + productname + "' ")
    print(res)
    return render_template('admin/view_approved_seller_product.html',data = res)


@app.route('/view_rejected_seller')
def view_rejected_seller():
    db = Db()
    res = db.select("SELECT * FROM `login`,`seller_model` WHERE `seller_model`.`login_id`=`login`.`login_id` AND login.type = 'reject'")
    return render_template('admin/view_rejected_seller.html',data = res)

@app.route('/view_rejected_seller_post', methods=['post'])
def view_rejected_seller_post():
    db = Db()
    sellername = request.form['textfield']
    res = db.select("SELECT * FROM `login`,`seller_model` WHERE `seller_model`.`login_id`=`login`.`login_id` AND login.type = 'reject' and seller_model.s_name='" + sellername + "' ")
    print(res)
    return render_template('admin/view_rejected_seller.html',data = res)

@app.route('/reject_seller/<s_id>')
def reject_seller(s_id):
    db = Db()
    print(s_id)
    db.update("update login set type = 'reject' where login_id = '"+s_id+"'")
    return "OK"


@app.route('/view_registered_seller')
def view_registered_seller():
    db = Db()
    res = db.select("SELECT `seller_model`.*, `login`.`type` FROM `login` INNER JOIN `seller_model` ON `seller_model`.`login_id`=`login`.`login_id` WHERE `login`.`type`='pending' ")

    print(res)
    return render_template('admin/view_registered_seller.html', data=res)


@app.route('/view_registered_seller_post', methods=['post'])
def view_registered_seller_post():
    db = Db()
    sellername = request.form['textfield']
    res = db.select("select * from seller_model WHERE s_name='" + sellername + "' ")
    print(res)
    return render_template('admin/view_registered_seller.html',data = res)



@app.route('/view_users')
def view_users():
    db = Db()
    res = db.select("select * from user_model ")
    print(res)
    return render_template('admin/view_users.html', data=res)

@app.route('/view_users_post', methods=['post'])
def view_users_post():
    db = Db()
    username = request.form['textfield']
    res = db.select("select * from user_model WHERE u_name='" + username + "' ")
    print(res)
    return render_template('admin/view_users.html',data = res)

@app.route('/view_profit')
def view_profit():
    db = Db()
    res = db.select("SELECT `user_model`.*,`package_model`.`p_name`,`package_model`.`p_amount`, `profit_model`.`amount`,`profit_model`.`date`,`profit_model`.`type` FROM `profit_model` INNER JOIN `user_model` ON `user_model`.`login_id`=`profit_model`.`user_id` INNER JOIN `buy_model` ON `buy_model`.`buy_id`=`profit_model`.`buy_id` INNER JOIN `package_model` ON `package_model`.`package_id`=`buy_model`.`package_id`  WHERE `buy_model`.`type`='subscription' UNION(SELECT `user_model`.*,`product_model`.`product_name` AS p_name,`product_model`.`product_price` AS `p_amount`, `profit_model`.`amount`,`profit_model`.`date`,`profit_model`.`type` FROM `profit_model` INNER JOIN `user_model` ON `user_model`.`login_id`=`profit_model`.`user_id` INNER JOIN `buy_model` ON `buy_model`.`buy_id`=`profit_model`.`buy_id` INNER JOIN `product_model` ON `product_model`.`product_id`=`buy_model`.`package_id`  WHERE `buy_model`.`type`='sales')")
    print(res)
    return render_template('admin/view_profit.html', data=res)

@app.route('/view_profit_post', methods=['post'])
def view_profit_post():
    db = Db()
    res = db.select("select * from profit_model ")
    print(res)
    return render_template('admin/view_profit.html',data = res)


@app.route('/home')
def home():
    return render_template('admin/home.html')




# -----------------------------templates--------------------------------------------

@app.route('/admin_index')
def admin_index():
    return render_template('admin/admin_index.html')


@app.route('/admin_index_post', methods=['post'])
def admin_index_post():
    return render_template('admin/admin_index.html')

@app.route("/and_login",methods=['post'])
def androidlogin():

    username=request.form["uname"]
    password=request.form["pswd"]

    db=Db()

    qry="SELECT * FROM login WHERE `username`='"+username+"' AND `password`='"+password+"'"
    print(qry)
    # return jsonify(status='no')
    res=db.selectOne(qry)
    print(qry)
    if res is not None:
        return jsonify(status='ok',lid=res['login_id'],type=res['type'])
    else:
        return jsonify(status='no')

@app.route("/and_signup",methods=['post'])
def andsignup():
    db=Db()
    s_name=request.form["name"]
    s_gender=request.form['gender']
    s_place=request.form['district']
    s_post=request.form['post']
    s_pincode=request.form['pin']
    s_email = request.form['email']
    s_phone = request.form['phone']
    s_image=request.files['image']
    password=request.form['password']
    import time
    timestr = time.strftime("%Y%m%d-%H%M%S")
    path="C:\\Users\\user\\PycharmProjects\\craftify\\static\\seller\\"+timestr+".jpg"
    s_image.save(path)

    filename="/static/seller/"+timestr+".jpg"

    qry="INSERT INTO login (`username`,`password`,`type`) VALUES('"+s_email+"','"+password+"','seller')"
    lid=db.insert(qry)

    qry="INSERT INTO `seller_model` (`s_name`,`s_gender`,`s_place`,`s_post`,`s_pincode`,`s_email`,`s_phone`,`s_image`,`login_id`) VALUES ('"+s_name+"','"+s_gender+"','"+s_place+"','"+s_post+"','"+s_pincode+"','"+s_email+"','"+s_phone+"','"+filename+"','"+str(lid)+"')"
    res=db.insert(qry)
    print(res)
    return jsonify(status='ok')



@app.route("/and_updateprofile",methods=['post'])
def and_updateprofile():
    db=Db()
    s_name=request.form["name"]
    s_gender=request.form['gender']
    s_place=request.form['district']
    s_post=request.form['post']
    s_pincode=request.form['pin']
    s_email = request.form['email']
    s_phone = request.form['phone']
    s_image=request.files['image']
    import time
    timestr = time.strftime("%Y%m%d-%H%M%S")
    path="C:\\Users\\user\\PycharmProjects\\craftify\\static\\seller\\"+timestr+".jpg"
    s_image.save(path)

    filename="/static/seller/"+timestr+".jpg"

    qry = "UPDATE seller_model SET  s_name='"+s_name+"',s_gender='"+s_gender+"',s_place='"+s_place+"',s_post='"+s_post+"',s_pincode='"+s_pincode+"',s_email ='"+s_email+"',s_phone='"+s_phone+"' "
    db.update(qry)

    return jsonify(status='ok')





@app.route("/and_view_profile",methods=['post'])
def and_view_profile():
    lid=request.form["lid"]
    qry="SELECT * FROM `seller_model` WHERE `login_id`='"+lid+"'"
    db=Db()
    res=db.selectOne(qry)
    return jsonify(status='ok',data=res)



@app.route("/and_view_products",methods=['post'])
def and_view_products():
    lid=request.form["lid"]
    qry="SELECT * FROM `product_model` WHERE `seller_id`='"+lid+"'"
    db=Db()
    res=db.select(qry)
    return jsonify(status='ok',data=res)
@app.route("/andaddproducts",methods=['post'])
def andaddproducts():
    db=Db()
    name=request.form["name"]
    count=request.form['count']
    details=request.form['details']
    price=request.form['price']
    lid=request.form['lid']

    s_image=request.files['image']
    import time
    timestr = time.strftime("%Y%m%d-%H%M%S")
    path="C:\\Users\\user\\PycharmProjects\\craftify\\static\\sellerproduct\\"+timestr+".jpg"
    s_image.save(path)

    filename="/static/sellerproduct/"+timestr+".jpg"

    qry="INSERT INTO `product_model` (`product_name`,`product_count`,`product_price`,`product_details`,`photo`,`seller_id`) VALUES ('"+name+"','"+count+"','"+price+"','"+details+"','"+filename+"','"+lid+"')"
    db.insert(qry)

    return jsonify(status='ok')



@app.route("/andaddproducts",methods=['post'])
def andaddprodccucts():
    db=Db()
    name=request.form["title"]
    count=request.form['count']
    details=request.form['details']
    price=request.form['price']
    lid=request.form['lid']

    s_image=request.files['image']
    import time
    timestr = time.strftime("%Y%m%d-%H%M%S")
    path="C:\\Users\\user\\PycharmProjects\\craftify\\static\\sellerproduct\\"+timestr+".jpg"
    s_image.save(path)

    filename="/static/sellerproduct/"+timestr+".jpg"

    qry="INSERT INTO `product_model` (`product_name`,`product_count`,`product_price`,`product_details`,`photo`,`seller_id`) VALUES ('"+name+"','"+count+"','"+price+"','"+details+"','"+filename+"','"+lid+"')"
    db.insert(qry)

    return jsonify(status='ok')



@app.route("/andaddvedios",methods=['post'])
def andaddvedios():
    db=Db()
    # video_name=request.form["video_name"]
    title=request.form['title']
    description=request.form['description']
    lid=request.form['lid']

    s_image=request.files['image']
    import time
    timestr = time.strftime("%Y%m%d-%H%M%S")
    path="C:\\Users\\user\\PycharmProjects\\craftify\\static\\tutorial\\"+s_image.filename
    s_image.save(path)

    filename="/static/tutorial/"+s_image.filename
    qry="INSERT INTO `tutorial_model`(title,`description`,`v_date`,`seller_id`,path) VALUES ('"+title+"','"+description+"',CURDATE(),'"+lid+"','"+filename+"')"
    db.insert(qry)

    return jsonify(status='ok')


@app.route("/and_view_tutorial",methods=['post'])
def and_view_tutorial():
    db=Db()

    lid=request.form['lid']



    qry="select * from `tutorial_model` where `seller_id`='"+lid+"'"
    res=db.select(qry)

    return jsonify(status='ok',data=res)

@app.route("/and_view_exhibition",methods=['post'])
def and_view_exhibition():
    db=Db()



    qry="select * from `exhibition_model` "
    res=db.select(qry)

    return jsonify(status='ok',data=res)


@app.route("/and__apply_exhibition",methods=['post'])
def and_apply_exhibition():
    db=Db()

    lid=request.form['lid']
    exid=request.form['exid']

    qry="INSERT INTO `exhition_request`(ulid,exibitionid,`date`,`status`) VALUES ('"+lid+"','"+exid+"',curdate(),'pending')"

    res=db.insert(qry)

    return jsonify(status='ok')


@app.route("/and_view_winner",methods=['post'])
def and_view_winner():
    db=Db()

    qry="select * from `winner_model` "
    res=db.select(qry)

    return jsonify(status='ok',data=res)


@app.route("/and_view_booking",methods=['post'])
def and_view_booking():
    db=Db()

    qry="select * from `master_model` "
    res=db.select(qry)

    return jsonify(status='ok',data=res)


@app.route("/and_view_rating",methods=['post'])
def and_view_rating():
    db=Db()
    pid=request.form["pid"]

    qry="SELECT `rating_model`.*,`user_model`.`u_name` FROM `rating_model` INNER JOIN `user_model` ON `rating_model`.`ulid`=`user_model`.`login_id` where rating_model.pid='"+pid+"' "
    res=db.select(qry)

    return jsonify(status='ok',data=res)




if __name__ == '__main__':
    app.run(debug=True,host='0.0.0.0',port=5050)


